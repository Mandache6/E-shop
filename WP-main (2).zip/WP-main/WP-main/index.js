
document.addEventListener("DOMContentLoaded", function () {
    var produkt = '[{"Auto":"Mercedes-Benz","Cena":904131,"Rokvyroby":2010},{"Auto":"GMC","Cena":614826,"Rokvyroby":1997},{"Auto":"GMC","Cena":827819,"Rokvyroby":1992}, {"Auto":"BMW","Cena":413157,"Rokvyroby":2001}, {"Auto":"Nissan","Cena":631772,"Rokvyroby":1997}, {"Auto":"Ford","Cena":466064,"Rokvyroby":2000}, {"Auto":"Hyundai","Cena":283983,"Rokvyroby":2010}, {"Auto":"Lotus","Cena":777883,"Rokvyroby":1986}, {"Auto":"Chevrolet","Cena":516260,"Rokvyroby":1997}, {"Auto":"Chevrolet","Cena":824685,"Rokvyroby":1995}, {"Auto":"Chevrolet","Cena":265117,"Rokvyroby":1979}, {"Auto":"Subaru","Cena":593325,"Rokvyroby":2006}, {"Auto":"Volkswagen","Cena":528502,"Rokvyroby":2003}, {"Auto":"GMC","Cena":790619,"Rokvyroby":2012}, {"Auto":"Toyota","Cena":245338,"Rokvyroby":2012}, {"Auto":"Merkur","Cena":159576,"Rokvyroby":1985},{"Auto":"Oldsmobile","Cena":889730,"Rokvyroby":1998},{"Auto":"Mitsubishi","Cena":801933,"Rokvyroby":2012},{"Auto":"Subaru","Cena":474423,"Rokvyroby":1987},{"Auto":"Pontiac","Cena":667110,"Rokvyroby":1987},{"Auto":"Chevrolet","Cena":643714,"Rokvyroby":2008}, {"Auto":"Toyota","Cena":992244,"Rokvyroby":1976}, {"Auto":"Mitsubishi","Cena":386326,"Rokvyroby":2005}, {"Auto":"Lexus","Cena":633787,"Rokvyroby":1999},{"Auto":"Toyota","Cena":625692,"Rokvyroby":1995},{"Auto":"Volvo","Cena":258375,"Rokvyroby":1998}, {"Auto":"Lexus","Cena":931251,"Rokvyroby":2005},{"Auto":"Mercury","Cena":382007,"Rokvyroby":1998}, {"Auto":"Dodge","Cena":781185,"Rokvyroby":2008}, {"Auto":"Chevrolet","Cena":986196,"Rokvyroby":2009}, {"Auto":"Audi","Cena":507593,"Rokvyroby":1997}, {"Auto":"Mitsubishi","Cena":519990,"Rokvyroby":1988}, {"Auto":"Volvo","Cena":988833,"Rokvyroby":2010}, {"Auto":"Chrysler","Cena":361460,"Rokvyroby":1926}, {"Auto":"GMC","Cena":657492,"Rokvyroby":2009}, {"Auto":"Lexus","Cena":419450,"Rokvyroby":2011}, {"Auto":"Plymouth","Cena":254720,"Rokvyroby":2000}, {"Auto":"Mercury","Cena":310447,"Rokvyroby":1999},  {"Auto":"Mercury","Cena":252441,"Rokvyroby":2003}, {"Auto":"Cadillac","Cena":797161,"Rokvyroby":2007}, {"Auto":"GMC","Cena":332913,"Rokvyroby":1996}, {"Auto":"Chevrolet","Cena":924205,"Rokvyroby":1991}, {"Auto":"Dodge","Cena":135355,"Rokvyroby":1996}, {"Auto":"Maybach","Cena":478600,"Rokvyroby":2003}, {"Auto":"Bentley","Cena":623162,"Rokvyroby":2009},  {"Auto":"Toyota","Cena":217416,"Rokvyroby":1993},  {"Auto":"Porsche","Cena":239353,"Rokvyroby":1998}, {"Auto":"Kia","Cena":962591,"Rokvyroby":2009}, {"Auto":"Saab","Cena":739545,"Rokvyroby":1996}, {"Auto":"GMC","Cena":820608,"Rokvyroby":1992}]';
    let objekty = JSON.parse(produkt);
    let sekceprodukty = document.getElementById("hlavni");
    let razeniCenaVzestupne = document.getElementById("razeniCenaVzestupne");
    let razeniCenaSestupne = document.getElementById("razeniCenaSestupne");
    let filtrButton = document.getElementById("filtr");
    let minCena = document.getElementById("minCena");
    let maxCena = document.getElementById("maxCena");

    for (let i = 0; i < objekty.length; i++) {
        let kontejner = document.createElement("article");
        kontejner.id = "produkt";
        let auto = document.createElement("span");
        let cena = document.createElement("p");
        let rokvyroby = document.createElement("p");
        let button = document.createElement("button");
        let nakup = document.createElement("button");
        kontejner.style.display = "flex";
        kontejner.style.flexDirection = "column";
        kontejner.style.alignItems = "center";
        kontejner.style.justifyContent = "space-evenly";
        kontejner.style.width = "20vw";
        kontejner.style.height = "20vh";
        kontejner.style.border = "1px solid black";
        kontejner.style.margin = "1vh";
        kontejner.style.fontSize = "1.5em";
        button.innerText = "Koupit";
        button.style.width = "40%";
        button.style.height = "25%";
        button.style.backgroundColor = "brown";
        button.style.color = "white";
        button.style.fontFamily = "Arial, Helvetica, sans-serif";
        button.style.fontSize = "1.2em";
        button.style.borderRadius = "3px";
        localStorage.setItem("produkt" + i, objekty[i].Produkt);
        nakup.innerText = "Koupit";
        nakup.id = "nakup"; 
        nakup.addEventListener("click", function () {
            localStorage.getItem("produkt" + i); 
            console.log(localStorage.getItem("produkt" + i)); 
        });
        auto.innerHTML += objekty[i].Auto;
        cena.innerHTML += objekty[i].Cena + " Kč";
        rokvyroby.innerHTML += objekty[i].Rokvyroby + "";
        sekceprodukty.append(kontejner);
        kontejner.append(auto);
        kontejner.append(cena);
        kontejner.append(rokvyroby);
        kontejner.append(nakup);
      

        filtrButton.addEventListener("click", function () {   
            let minimalniCena = minCena.value;
            let maximalniCena = maxCena.value;
            if (objekty[i].Cena >= minimalniCena && objekty[i].Cena <= maximalniCena) {
              
            } else {
                kontejner.style.display = "none";
            }
        });

        razeniCenaVzestupne.addEventListener("click", function () {
            objekty.sort(function (a, b) {
                return a.Cena - b.Cena;
            });
            produkt.innerHTML = objekty[i].Produkt;
            cena.innerHTML = objekty[i].Cena + " Kč";
        });

        razeniCenaSestupne.addEventListener("click", function () {
            objekty.sort(function (a, b) {
                return b.Cena - a.Cena;
            });
            produkt.innerHTML = objekty[i].Produkt;
            cena.innerHTML = objekty[i].Cena + " Kč";
        });

        if (localStorage) {
            localStorage.produkt = objekty[i].Produkt;
        }

    } 


}); 